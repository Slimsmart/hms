<footer>
				<div class="footer-inner">
					<div class="pull-left">
						<span>A Project Written by Ikparen Orjime David and Supervised By Mr. Tivlumun Ge.</span>
						&copy; <span class="current-year"></span><span class="text-bold text-uppercase"> HRMS</span>. <span>All rights reserved</span>
					</div>
					<div class="pull-right">
						<span class="go-top"><i class="ti-angle-up"></i></span>
					</div>
				</div>
			</footer>